export const STEM_FILES = [
  '/neffex_fight_back/bass.mp3',
  '/neffex_fight_back/drums.mp3',
  '/neffex_fight_back/guitar.mp3',
  '/neffex_fight_back/other.mp3',
  '/neffex_fight_back/piano.mp3',
  '/neffex_fight_back/vocals.mp3'
];

export const BOO_SOUND = '/freesound_community-boo-6377.mp3';

export class StemPlayer {
  ctx: AudioContext | null = null;
  buffers: AudioBuffer[] = [];
  booBuffer: AudioBuffer | null = null;
  sources: AudioBufferSourceNode[] = [];
  gains: GainNode[] = [];
  guitarGain: GainNode | null = null;
  startTime: number = 0;
  
  fallbackStartTime: number = 0;
  
  async load(onProgress?: (progress: { loaded: number; total: number; currentFile: string; error?: string }) => void) {
    try {
      if (!this.ctx) {
        this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
    } catch (e) {
      console.error("Failed to create AudioContext:", e);
      onProgress?.({ loaded: 0, total: 7, currentFile: '', error: 'Failed to initialize AudioContext' });
      return;
    }

    const totalFiles = 1 + STEM_FILES.length;
    let loadedCount = 0;

    const loadWithProgress = async (url: string, name: string) => {
      try {
        onProgress?.({ loaded: loadedCount, total: totalFiles, currentFile: name });
        const buffer = await this.fetchAudio(url);
        loadedCount++;
        onProgress?.({ loaded: loadedCount, total: totalFiles, currentFile: name });
        return buffer;
      } catch (e: any) {
        console.error(`Failed loading ${name}:`, e);
        onProgress?.({ loaded: loadedCount, total: totalFiles, currentFile: name, error: `Failed to load ${name}: ${e.message || e}` });
        throw e;
      }
    };

    try {
      const boo = await loadWithProgress(BOO_SOUND, 'Audience Sound (Boo)');
      
      const stems: AudioBuffer[] = [];
      for (let i = 0; i < STEM_FILES.length; i++) {
        const url = STEM_FILES[i];
        const stemName = url.split('/').pop() || url;
        const buffer = await loadWithProgress(url, `Stem: ${stemName}`);
        stems.push(buffer);
      }

      this.booBuffer = boo;
      this.buffers = stems;
    } catch (err: any) {
      console.error("Fatal Load Error in StemPlayer:", err);
      // Let's call onProgress with error so the UI displays it
      onProgress?.({
        loaded: loadedCount,
        total: totalFiles,
        currentFile: '',
        error: err.message || String(err)
      });
      // Propagate the error so the game doesn't start with silence
      throw err;
    }
  }

  async fetchAudio(url: string) {
    try {
      console.log("[AudioLoader] Fetching:", url);
      const res = await fetch(url);
      console.log(`[AudioLoader] Response status for ${url}: ${res.status} (${res.statusText})`);
      if (!res.ok) {
        throw new Error(`Fetch failed with status ${res.status} for ${url}`);
      }
      
      const contentType = res.headers.get("content-type");
      const contentLength = res.headers.get("content-length");
      console.log(`[AudioLoader] Meta for ${url} - Content-Type: ${contentType}, Content-Length: ${contentLength}`);
      
      const arrayBuffer = await res.arrayBuffer();
      console.log(`[AudioLoader] Got ArrayBuffer for ${url}, length: ${arrayBuffer.byteLength} bytes.`);
      
      if (arrayBuffer.byteLength === 0) {
        throw new Error(`Fetched empty response (0 bytes) for ${url}`);
      }
      
      return await new Promise<AudioBuffer>((resolve, reject) => {
        this.ctx!.decodeAudioData(
          arrayBuffer,
          (decodedBuffer) => {
            console.log(`[AudioLoader] Decoded successfully: ${url}`, {
              duration: decodedBuffer.duration,
              sampleRate: decodedBuffer.sampleRate,
              numberOfChannels: decodedBuffer.numberOfChannels,
              length: decodedBuffer.length
            });
            resolve(decodedBuffer);
          },
          (err) => {
            console.error(`[AudioLoader] Decode error on ${url}:`, err);
            reject(new Error(`Failed to decode audio data for ${url}`));
          }
        );
      });
    } catch (e: any) {
      console.error("[AudioLoader] Fatal error in fetchAudio for", url, e);
      throw new Error(e.message || `Decoding or fetch error for ${url}`);
    }
  }

  analyzeNotes(difficulty: 'easy'|'medium'|'hard' = 'medium'): { time: number, lane: number }[] {
    if (this.buffers.length < 6) return [];
    
    // Map of lane -> buffer index
    // Lane 0: Bass (0)
    // Lane 1: Drums (1)
    // Lane 2: Piano (4)
    // Lane 3: Guitar (2)
    // Lane 4: Vocals (5)
    const laneMappings = [0, 1, 4, 2, 5];
    
    const allNotes: { time: number, lane: number }[] = [];
    
    laneMappings.forEach((bufferIdx, lane) => {
      const buffer = this.buffers[bufferIdx];
      const rawData = buffer.getChannelData(0);
      const sampleRate = buffer.sampleRate;
      
      const windowSize = Math.floor(sampleRate * 0.05); // 50ms
      const hopSize = Math.floor(sampleRate * 0.03); // 30ms (larger hop to save processing)
      
      let previousEnergy = 0;
      let lastNoteTime = 0;
      
      // Defaults for medium
      let thresholdMult = 1.0;
      let minIntervalBase = 0.5;
      
      if (difficulty === 'easy') {
        thresholdMult = 1.5;
        minIntervalBase = 1.0; // 1 note per sec per lane
      } else if (difficulty === 'hard') {
        thresholdMult = 0.6;
        minIntervalBase = 0.25; // 4 notes per sec per lane
      }

      const threshold = (bufferIdx === 1 ? 0.08 : 0.04) * thresholdMult;
      const minNoteInterval = minIntervalBase;
      
      for (let i = 0; i < rawData.length - windowSize; i += hopSize) {
        let sum = 0;
        for (let j = 0; j < windowSize; j+=4) { // step by 4 to optimize
          sum += rawData[i + j] * rawData[i + j];
        }
        const energy = Math.sqrt(sum / (windowSize / 4));
        
        if (energy > previousEnergy * 1.8 && energy > threshold) {
          const time = i / sampleRate;
          if (time - lastNoteTime > minNoteInterval) {
            allNotes.push({ time, lane });
            lastNoteTime = time;
          }
        }
        previousEnergy = energy;
      }
    });
    
    // Sort chronologically
    allNotes.sort((a, b) => a.time - b.time);
    
    return allNotes;
  }

  play() {
    console.log("StemPlayer play() called. ctx:", !!this.ctx, "buffers:", this.buffers.length);
    if (!this.ctx || this.buffers.length === 0) return;
    
    // Resume context in case it was created without user gesture and suspended
    if (this.ctx.state === 'suspended') {
      console.log("Resuming suspended context...");
      this.ctx.resume();
    }
    
    // Stop any existing
    this.stop();
    
    this.sources = [];
    this.gains = [];
    
    const delay = 3.0; // 3 seconds delay before audio starts
    const t = this.ctx.currentTime + delay;
    console.log(`Starting audio at context time ${t} (current time ${this.ctx.currentTime})`);
    this.startTime = this.ctx.currentTime; // Game clock starts immediately
    this.fallbackStartTime = performance.now() / 1000;
    
    this.buffers.forEach((buffer, i) => {
      const source = this.ctx!.createBufferSource();
      source.buffer = buffer;
      
      const gain = this.ctx!.createGain();
      gain.gain.value = 1;
      
      source.connect(gain);
      gain.connect(this.ctx!.destination);
      
      if (STEM_FILES[i] && STEM_FILES[i].includes('guitar.mp3')) {
        this.guitarGain = gain;
      }
      
      source.start(t);
      this.sources.push(source);
      this.gains.push(gain);
    });
    console.log(`Started ${this.sources.length} sources`);
  }

  stop() {
    this.sources.forEach(s => {
      try { s.stop(); } catch(e){}
    });
    this.sources = [];
  }

  muteInstrument(lane: number, duration: number = 4.0) {
    if (!this.ctx || this.gains.length < 6) return;
    
    const laneMappings = [0, 1, 4, 2, 5];
    const bufferIdx = laneMappings[lane];
    
    const t = this.ctx.currentTime;
    
    if (bufferIdx !== undefined && this.gains[bufferIdx]) {
      const gainNode = this.gains[bufferIdx];
      gainNode.gain.cancelScheduledValues(t);
      // Fast fade out to 0.2 to muffle rather than silence
      gainNode.gain.linearRampToValueAtTime(0.2, t + 0.1);
      // Keep muffled, then slowly restore to 1.0 (auto-recovery in case there are no notes for a while)
      gainNode.gain.setValueAtTime(0.2, t + duration);
      gainNode.gain.linearRampToValueAtTime(1, t + duration + 1.5);
    }
    
    // Play boo occasionally
    if (this.booBuffer && Math.random() > 0.8) {
      const source = this.ctx.createBufferSource();
      source.buffer = this.booBuffer;
      const gain = this.ctx.createGain();
      gain.gain.value = 0.4;
      source.connect(gain);
      gain.connect(this.ctx.destination);
      source.start(t);
    }
  }

  unmuteInstrument(lane: number) {
    if (!this.ctx || this.gains.length < 6) return;
    
    const laneMappings = [0, 1, 4, 2, 5];
    const bufferIdx = laneMappings[lane];
    
    const t = this.ctx.currentTime;
    
    if (bufferIdx !== undefined && this.gains[bufferIdx]) {
      const gainNode = this.gains[bufferIdx];
      gainNode.gain.cancelScheduledValues(t);
      // Smoothly and quickly restore volume
      gainNode.gain.linearRampToValueAtTime(1, t + 0.1);
    }
  }

  getCurrentTime(): number {
    if (!this.ctx || this.sources.length === 0 || this.ctx.currentTime === 0) {
      if (this.fallbackStartTime === 0) return 0;
      return (performance.now() / 1000 - this.fallbackStartTime) - 3.0;
    }
    // Return time relative to the music start. Negatives mean countdown.
    return (this.ctx.currentTime - this.startTime) - 3.0;
  }
}
