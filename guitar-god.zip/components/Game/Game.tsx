import React, { useRef, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { useStore, NoteData } from '../../store';
import { stemPlayer } from '../UI/Menu';
import * as THREE from 'three';
import { EffectComposer, Bloom } from '@react-three/postprocessing';

const LANE_WIDTH = 1.0;
const LANE_COUNT = 5;
const START_X = -(LANE_COUNT * LANE_WIDTH) / 2 + (LANE_WIDTH / 2);
const FALL_SPEED = 10; // units per second
const TARGET_Z = 5;

// Colors matching typical rhythm games
const LANE_COLORS = ['#22c55e', '#ef4444', '#eab308', '#3b82f6', '#f97316'];
const KEYS = ['KeyA', 'KeyS', 'KeyD', 'KeyF', 'KeyG'];

// Simple CSS/Geometry human rockstars
function HumanDrummer() {
  const armRefR = useRef<THREE.Group>(null);
  const armRefL = useRef<THREE.Group>(null);
  const headRef = useRef<THREE.Mesh>(null);
  
  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    if (armRefR.current) armRefR.current.rotation.x = Math.sin(t * 8) * 0.5 - 0.5;
    if (armRefL.current) armRefL.current.rotation.x = Math.cos(t * 8) * 0.5 - 0.5;
    if (headRef.current) {
       headRef.current.rotation.x = Math.sin(t * 4) * 0.2;
       headRef.current.rotation.z = Math.cos(t * 2) * 0.1;
    }
  });

  return (
    <group position={[0, 2, -4]}>
      {/* Body */}
      <mesh position={[0, 1.5, 0]}>
        <boxGeometry args={[1.2, 1.5, 0.8]} />
        <meshStandardMaterial color="#222" />
      </mesh>
      {/* Head */}
      <mesh ref={headRef} position={[0, 2.8, 0]}>
        <boxGeometry args={[0.8, 0.8, 0.8]} />
        <meshStandardMaterial color="#fcd5ce" />
      </mesh>
      {/* Hair */}
      <mesh position={[0, 3.2, -0.1]}>
        <boxGeometry args={[0.9, 0.4, 0.9]} />
        <meshStandardMaterial color="#111" />
      </mesh>
      {/* Right Arm */}
      <group position={[0.7, 2.0, 0]} ref={armRefR}>
        <mesh position={[0, -0.6, 0.4]} rotation={[-0.5, 0, 0]}>
          <cylinderGeometry args={[0.15, 0.15, 1.5]} />
          <meshStandardMaterial color="#fcd5ce" />
        </mesh>
        {/* Drumstick */}
        <mesh position={[0, -1.3, 0.8]} rotation={[-1.0, 0, 0]}>
          <cylinderGeometry args={[0.03, 0.03, 1.0]} />
          <meshStandardMaterial color="#eee" />
        </mesh>
      </group>
      {/* Left Arm */}
      <group position={[-0.7, 2.0, 0]} ref={armRefL}>
        <mesh position={[0, -0.6, 0.4]} rotation={[-0.5, 0, 0]}>
          <cylinderGeometry args={[0.15, 0.15, 1.5]} />
          <meshStandardMaterial color="#fcd5ce" />
        </mesh>
        {/* Drumstick */}
        <mesh position={[0, -1.3, 0.8]} rotation={[-1.0, 0, 0]}>
          <cylinderGeometry args={[0.03, 0.03, 1.0]} />
          <meshStandardMaterial color="#eee" />
        </mesh>
      </group>
    </group>
  );
}

function HumanGuitarist() {
  const bodyRef = useRef<THREE.Group>(null);
  const headRef = useRef<THREE.Mesh>(null);
  const strumArmRef = useRef<THREE.Group>(null);
  
  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    if (bodyRef.current) {
      bodyRef.current.position.y = Math.sin(t * 4) * 0.2;
      bodyRef.current.position.x = Math.cos(t * 2) * 0.5 - 2;
      bodyRef.current.rotation.z = Math.sin(t * 2) * 0.1;
      bodyRef.current.rotation.y = Math.cos(t * 1.5) * 0.2 + 0.5;
    }
    if (headRef.current) {
      headRef.current.rotation.x = Math.sin(t * 8) * 0.3 + 0.2; // Headbanging
    }
    if (strumArmRef.current) {
      strumArmRef.current.rotation.x = Math.sin(t * 16) * 0.4; // Fast strumming
    }
  });

  return (
    <group ref={bodyRef} position={[-2, 0, -2]}>
      {/* Legs */}
      <mesh position={[-0.3, 1.0, 0]} rotation={[0, 0, 0.2]}>
        <boxGeometry args={[0.4, 2.0, 0.4]} />
        <meshStandardMaterial color="#111" />
      </mesh>
      <mesh position={[0.3, 1.0, 0]} rotation={[0, 0, -0.2]}>
        <boxGeometry args={[0.4, 2.0, 0.4]} />
        <meshStandardMaterial color="#111" />
      </mesh>
      {/* Body */}
      <mesh position={[0, 2.5, 0]}>
        <boxGeometry args={[1.2, 1.5, 0.6]} />
        <meshStandardMaterial color="#333" />
      </mesh>
      {/* Head */}
      <mesh ref={headRef} position={[0, 3.8, 0]}>
        <group>
          <mesh>
            <boxGeometry args={[0.8, 0.8, 0.8]} />
            <meshStandardMaterial color="#fcd5ce" />
          </mesh>
          {/* Long Hair */}
          <mesh position={[0, 0, -0.2]}>
            <boxGeometry args={[0.9, 1.2, 0.6]} />
            <meshStandardMaterial color="#111" />
          </mesh>
        </group>
      </mesh>
      {/* Guitar */}
      <group position={[0, 2.3, 0.4]} rotation={[0, 0, 0.5]}>
        {/* Guitar Body */}
        <mesh position={[0.5, -0.2, 0]}>
          <boxGeometry args={[1.2, 0.8, 0.1]} />
          <meshStandardMaterial color="#eab308" />
        </mesh>
        {/* Guitar Neck */}
        <mesh position={[-0.8, 0, 0]}>
          <boxGeometry args={[1.5, 0.15, 0.05]} />
          <meshStandardMaterial color="#555" />
        </mesh>
      </group>
      {/* Left Arm (Fretting) */}
      <mesh position={[-0.7, 2.8, 0.2]} rotation={[0, 0, 0.8]}>
        <boxGeometry args={[0.3, 1.5, 0.3]} />
        <meshStandardMaterial color="#333" />
      </mesh>
      {/* Right Arm (Strumming) */}
      <group position={[0.7, 2.8, 0.2]} ref={strumArmRef}>
        <mesh position={[0, -0.6, 0.2]}>
          <boxGeometry args={[0.3, 1.2, 0.3]} />
          <meshStandardMaterial color="#333" />
        </mesh>
      </group>
    </group>
  );
}

function DiveBarScene() {
  const neonRef = useRef<THREE.PointLight>(null);
  const spot1Ref = useRef<THREE.SpotLight>(null);
  const spot2Ref = useRef<THREE.SpotLight>(null);
  
  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    if (neonRef.current) {
      neonRef.current.intensity = 2 + Math.sin(t * 10) * 0.5 + Math.random() * 0.5;
    }
    if (spot1Ref.current && spot1Ref.current.target) {
      spot1Ref.current.target.position.x = Math.sin(t * 2) * 10;
      spot1Ref.current.target.position.z = Math.cos(t * 0.5) * 5;
      spot1Ref.current.target.updateMatrixWorld();
    }
    if (spot2Ref.current && spot2Ref.current.target) {
      spot2Ref.current.target.position.x = Math.cos(t * 1.5) * 10;
      spot2Ref.current.target.position.z = Math.sin(t * 0.8) * 5;
      spot2Ref.current.target.updateMatrixWorld();
    }
  });

  return (
    <group position={[0, -2, -25]}>
      <mesh position={[0, 15, -5]}>
        <planeGeometry args={[100, 50]} />
        <meshStandardMaterial color="#0a0510" roughness={0.8} />
      </mesh>
      
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 10]}>
        <planeGeometry args={[80, 40]} />
        <meshStandardMaterial color="#1a1a24" roughness={0.6} metalness={0.2} />
      </mesh>

      <HumanDrummer />
      <HumanGuitarist />

      <group position={[-10, 4, 0]}>
        <mesh position={[0, 0, 0]}>
          <boxGeometry args={[4, 8, 3]} />
          <meshStandardMaterial color="#111" />
        </mesh>
        <mesh position={[0, 2, 1.51]}>
          <circleGeometry args={[1.2, 16]} />
          <meshBasicMaterial color="#050505" />
        </mesh>
        <mesh position={[0, -2, 1.51]}>
          <circleGeometry args={[1.5, 16]} />
          <meshBasicMaterial color="#050505" />
        </mesh>
      </group>
      
      <group position={[10, 4, 0]}>
        <mesh position={[0, 0, 0]}>
          <boxGeometry args={[4, 8, 3]} />
          <meshStandardMaterial color="#111" />
        </mesh>
        <mesh position={[0, 2, 1.51]}>
          <circleGeometry args={[1.2, 16]} />
          <meshBasicMaterial color="#050505" />
        </mesh>
        <mesh position={[0, -2, 1.51]}>
          <circleGeometry args={[1.5, 16]} />
          <meshBasicMaterial color="#050505" />
        </mesh>
      </group>

      <group position={[0, 1.5, -2]}>
        <mesh position={[0, 0, 1]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[2, 2, 2, 32]} />
          <meshStandardMaterial color="#700" roughness={0.3} metalness={0.5} />
        </mesh>
        <mesh position={[0, 0, 2.01]} rotation={[Math.PI / 2, 0, 0]}>
          <circleGeometry args={[1.9, 32]} />
          <meshStandardMaterial color="#ddd" roughness={0.8} />
        </mesh>
        <mesh position={[2.5, 0.5, 0]}>
          <cylinderGeometry args={[1.2, 1.2, 2, 16]} />
          <meshStandardMaterial color="#700" roughness={0.3} />
        </mesh>
        <mesh position={[-2, 1.5, 0]}>
          <cylinderGeometry args={[0.8, 0.8, 0.6, 16]} />
          <meshStandardMaterial color="#eee" roughness={0.8} />
        </mesh>
        <mesh position={[-3, 4, -1]} rotation={[-0.2, 0, 0.2]}>
          <cylinderGeometry args={[1.5, 1.5, 0.05, 16]} />
          <meshStandardMaterial color="#eab308" roughness={0.1} metalness={0.9} />
        </mesh>
        <mesh position={[2.5, 4.5, -1]} rotation={[-0.2, 0, -0.2]}>
          <cylinderGeometry args={[1.2, 1.2, 0.05, 16]} />
          <meshStandardMaterial color="#eab308" roughness={0.1} metalness={0.9} />
        </mesh>
      </group>
      
      <group position={[-5, 2, -6]}>
        <mesh><boxGeometry args={[3, 4, 2]} /><meshStandardMaterial color="#1a1a1a" /></mesh>
      </group>
      <group position={[5, 2, -6]}>
        <mesh><boxGeometry args={[3, 4, 2]} /><meshStandardMaterial color="#1a1a1a" /></mesh>
      </group>

      <group position={[0, 12, -4.5]}>
        <pointLight ref={neonRef} color="#ec4899" distance={40} decay={2} intensity={2} />
        <mesh>
          <boxGeometry args={[15, 3, 0.2]} />
          <meshStandardMaterial color="#ec4899" emissive="#ec4899" emissiveIntensity={2} />
        </mesh>
      </group>
      
      <group position={[-15, 15, 5]}>
        <spotLight ref={spot1Ref} angle={0.4} penumbra={0.5} intensity={5} color="#3b82f6" distance={50} />
      </group>
      <group position={[15, 15, 5]}>
        <spotLight ref={spot2Ref} angle={0.4} penumbra={0.5} intensity={5} color="#eab308" distance={50} />
      </group>
      
    </group>
  );
}

const CameraController = () => {
  const { camera, size } = useThree();
  useFrame(() => {
    const aspect = size.width / size.height;

    if (aspect < 1.0) {
      camera.position.set(0, 6.5, TARGET_Z + 5.5);
      camera.lookAt(0, 1.5, TARGET_Z - 10);
    } else {
      camera.position.set(0, 4.0, TARGET_Z + 4.0);
      camera.lookAt(0, 0.0, TARGET_Z - 10);
    }
  });
  return null;
}

function getFallSpeed(difficulty: string) {
  return difficulty === 'hard' ? 16 : difficulty === 'easy' ? 8 : 12;
}

function NoteObject({ note, index }: { note: NoteData, index: number }) {
  const meshRef = useRef<THREE.Group>(null);
  const difficulty = useStore(s => s.difficulty);

  useFrame(({ clock }) => {
    if (!meshRef.current || note.hit || note.missed) return;
    const currentTime = stemPlayer.getCurrentTime();
    const timeDiff = note.time - currentTime;
    
    if (timeDiff > 5 || timeDiff < -1) {
      meshRef.current.position.y = -100;
    } else {
      meshRef.current.position.y = 0.2;
      const speed = getFallSpeed(difficulty);
      const z = TARGET_Z - (timeDiff * speed);
      meshRef.current.position.z = z;
      
      if (Math.abs(timeDiff) < 0.2) {
        meshRef.current.scale.setScalar(1.2);
      } else {
        meshRef.current.scale.setScalar(1);
      }
    }
  });

  if (note.hit || note.missed) return null;

  return (
    <group ref={meshRef} position={[START_X + note.lane * LANE_WIDTH, -100, -100]}>
      <mesh>
        <cylinderGeometry args={[0.45, 0.45, 0.15, 32]} />
        <meshStandardMaterial color={LANE_COLORS[note.lane]} emissive={LANE_COLORS[note.lane]} emissiveIntensity={0.5} roughness={0.1} metalness={0.8} />
      </mesh>
      {/* Target Ring */}
      <mesh position={[0, 0.08, 0]}>
        <cylinderGeometry args={[0.3, 0.3, 0.02, 32]} />
        <meshBasicMaterial color="#fff" />
      </mesh>
    </group>
  );
}

function ScrollingFrets() {
  const fretsRef = useRef<THREE.Group>(null);
  const fretSpacing = 4;
  const numFrets = 15;
  const length = fretSpacing * numFrets;
  const difficulty = useStore(s => s.difficulty);

  useFrame(() => {
    if (fretsRef.current) {
      const time = stemPlayer.getCurrentTime();
      const speed = getFallSpeed(difficulty);
      // Move frets towards camera (positive z) based on speed
      const zOffset = (time * speed) % fretSpacing;
      fretsRef.current.position.z = zOffset;
    }
  });

  return (
    <group ref={fretsRef}>
      {Array.from({ length: numFrets }).map((_, i) => (
        <mesh key={`fret-${i}`} position={[0, 0.05, TARGET_Z - i * fretSpacing]}>
          <boxGeometry args={[LANE_COUNT * LANE_WIDTH, 0.02, 0.05]} />
          <meshBasicMaterial color="#333" />
        </mesh>
      ))}
    </group>
  );
}

function Fretboard({ keysPressed, setKeysPressed }: { keysPressed: boolean[], setKeysPressed: React.Dispatch<React.SetStateAction<boolean[]>> }) {
  const hitNote = useStore(s => s.hitNote);

  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.01, TARGET_Z - 20]}>
        <planeGeometry args={[LANE_COUNT * LANE_WIDTH, 50]} />
        <meshStandardMaterial color="#080808" roughness={0.8} />
      </mesh>
      
      <ScrollingFrets />

      <mesh position={[0, 0.1, TARGET_Z]}>
        <boxGeometry args={[LANE_COUNT * LANE_WIDTH, 0.1, 0.8]} />
        <meshStandardMaterial color="#111" />
      </mesh>

      {KEYS.map((_, i) => (
        <group key={i}>
          {/* Visual Target */}
          <mesh position={[START_X + i * LANE_WIDTH, 0.15, TARGET_Z]}>
            <cylinderGeometry args={[0.5, 0.5, 0.1, 32]} />
            <meshStandardMaterial 
              color={keysPressed[i] ? LANE_COLORS[i] : '#333'} 
              emissive={keysPressed[i] ? LANE_COLORS[i] : '#000'}
              emissiveIntensity={keysPressed[i] ? 4.0 : 0}
            />
          </mesh>
        </group>
      ))}

      {/* Invisible Touch Hitbox covering entire track */}
      <mesh 
        position={[0, 0.5, TARGET_Z - 10]}
        rotation={[-Math.PI / 2, 0, 0]}
        onPointerDown={(e) => {
          e.stopPropagation();
          (e.target as any).setPointerCapture(e.pointerId);
          // calculate lane based on event x position
          let x = e.point.x;
          // map x to lane 0-4
          const lane = Math.floor((x - START_X + (LANE_WIDTH / 2)) / LANE_WIDTH);
          if (lane >= 0 && lane < 5) {
            setKeysPressed(prev => { const n = [...prev]; n[lane] = true; return n; });
            const hit = hitNote(lane, stemPlayer.getCurrentTime());
            if (hit.hit) {
              stemPlayer.unmuteInstrument(lane);
            } else {
              stemPlayer.muteInstrument(lane);
            }
          }
        }}
        onPointerMove={(e) => {
          // Allow dragging across lanes
          if ((e.target as any).hasPointerCapture(e.pointerId)) {
            let x = e.point.x;
            const lane = Math.floor((x - START_X + (LANE_WIDTH / 2)) / LANE_WIDTH);
            if (lane >= 0 && lane < 5 && !keysPressed[lane]) {
              setKeysPressed(prev => { const n = [false, false, false, false, false]; n[lane] = true; return n; });
              const hit = hitNote(lane, stemPlayer.getCurrentTime());
              if (hit.hit) {
                stemPlayer.unmuteInstrument(lane);
              } else {
                stemPlayer.muteInstrument(lane);
              }
            }
          }
        }}
        onPointerUp={(e) => {
          e.stopPropagation();
          (e.target as any).releasePointerCapture(e.pointerId);
          setKeysPressed([false, false, false, false, false]);
        }}
        onPointerOut={(e) => {
          e.stopPropagation();
          setKeysPressed([false, false, false, false, false]);
        }}
        onPointerCancel={(e) => {
          e.stopPropagation();
          setKeysPressed([false, false, false, false, false]);
        }}
      >
        <planeGeometry args={[LANE_COUNT * LANE_WIDTH * 1.5, 40]} />
        <meshBasicMaterial visible={false} />
      </mesh>

      {Array.from({ length: LANE_COUNT + 1 }).map((_, i) => (
        <mesh key={i} position={[START_X - LANE_WIDTH/2 + i * LANE_WIDTH, 0.05, TARGET_Z - 20]}>
          <boxGeometry args={[0.05, 0.05, 50]} />
          <meshBasicMaterial color="#333" />
        </mesh>
      ))}
    </group>
  );
}

function GameScene({ keysPressed, setKeysPressed }: { keysPressed: boolean[], setKeysPressed: React.Dispatch<React.SetStateAction<boolean[]>> }) {
  const notes = useStore(s => s.notes);
  
  return (
    <>
      <color attach="background" args={['#050510']} />
      <ambientLight intensity={0.4} />
      <pointLight position={[0, 5, 5]} intensity={1.0} color="#fff" />
      
      <DiveBarScene />
      
      <Fretboard keysPressed={keysPressed} setKeysPressed={setKeysPressed} />
      {notes.map((note, i) => (
        <NoteObject key={note.id} note={note} index={i} />
      ))}
      <EffectComposer>
        <Bloom luminanceThreshold={0.5} luminanceSmoothing={0.9} height={300} intensity={1.5} />
      </EffectComposer>
    </>
  );
}

export function Game() {
  const [keysPressed, setKeysPressed] = React.useState([false, false, false, false, false]);
  const [progress, setProgress] = React.useState(0);
  const { score, combo, multiplier, hitNote, missNote, notes, reset } = useStore();
  
  // Audio stop on unmount
  useEffect(() => {
    return () => stemPlayer.stop();
  }, []);

  // Update loop for misses and progress
  useEffect(() => {
    const interval = setInterval(() => {
      const time = stemPlayer.getCurrentTime();
      setProgress(Math.min(100, Math.max(0, (time / 185) * 100)));
      
      const activeNotes = useStore.getState().notes;
      activeNotes.forEach(note => {
        if (!note.hit && !note.missed && note.time < time - 0.2) {
          missNote(note.id);
          stemPlayer.muteInstrument(note.lane); // Miss! Mute specific instrument!
        }
      });
      // Check if song ended
      if (time > 185) {
        reset();
      }
    }, 100);
    return () => clearInterval(interval);
  }, [missNote, reset]);

  // Input Handling
  useEffect(() => {
    const onDown = (e: KeyboardEvent) => {
      if (e.repeat) return;
      const lane = KEYS.indexOf(e.code);
      if (lane !== -1) {
        setKeysPressed(prev => {
           const n = [...prev];
           n[lane] = true;
           return n;
        });
        const hit = hitNote(lane, stemPlayer.getCurrentTime());
        if (hit.hit) {
          stemPlayer.unmuteInstrument(lane);
        } else {
          // Missed because pressed when no note
          stemPlayer.muteInstrument(lane);
        }
      }
    };
    const onUp = (e: KeyboardEvent) => {
      const lane = KEYS.indexOf(e.code);
      if (lane !== -1) {
        setKeysPressed(prev => {
           const n = [...prev];
           n[lane] = false;
           return n;
        });
      }
    };
    
    window.addEventListener('keydown', onDown);
    window.addEventListener('keyup', onUp);
    return () => {
      window.removeEventListener('keydown', onDown);
      window.removeEventListener('keyup', onUp);
    };
  }, [hitNote]);

  return (
    <div className="absolute inset-0 font-cyber selection:bg-pink-500">
      <div className="absolute top-4 left-4 z-10 flex gap-12 drop-shadow-[0_0_10px_rgba(0,0,0,0.8)]">
        <div>
          <div className="text-pink-400 text-xs uppercase tracking-[0.2em] font-bold mb-1">Score</div>
          <div className="text-4xl text-white font-black tracking-tighter">{score.toLocaleString()}</div>
        </div>
        <div>
          <div className="text-purple-400 text-xs uppercase tracking-[0.2em] font-bold mb-1">Combo</div>
          <div className="text-4xl font-black text-white tracking-tighter">{combo} <span className="text-xl text-pink-500">x{multiplier}</span></div>
        </div>
      </div>

      <div className="absolute top-4 right-4 z-10 w-48 md:w-64">
        <div className="text-zinc-400 text-xs uppercase tracking-widest font-bold mb-1 text-right">Track Progress</div>
        <div className="h-2 w-full bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
          <div className="h-full bg-gradient-to-r from-pink-500 to-purple-500 transition-all duration-100" style={{ width: `${progress}%` }}></div>
        </div>
      </div>

      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] max-w-full h-[600px] pointer-events-none flex justify-center z-30">
        {useStore(s => s.recentHits).map(hit => (
          <div
            key={hit.id}
            className={`absolute animate-bounce-up ${hit.color} text-4xl uppercase tracking-widest`}
            style={{
              left: `${15 + hit.lane * 17.5}%`,
              bottom: '20%'
            }}
          >
            {hit.text}
          </div>
        ))}
      </div>

      <div className="absolute bottom-4 left-0 w-full text-center z-10 pointer-events-none text-zinc-500 text-sm tracking-widest font-bold hidden md:block">
        PRESS <span className="text-green-500">A</span> <span className="text-red-500">S</span> <span className="text-yellow-500">D</span> <span className="text-blue-500">F</span> <span className="text-orange-500">G</span> OR CLICK/TOUCH LANES
      </div>

      <Canvas camera={{ position: [0, 4, TARGET_Z + 4], fov: 60, rotation: [-0.4, 0, 0] }}>
        <CameraController />
        <fog attach="fog" args={['#050510', 20, 60]} />
        <GameScene keysPressed={keysPressed} setKeysPressed={setKeysPressed} />
      </Canvas>
    </div>
  );
}
