import React, { useState, useEffect } from 'react';
import { useStore, NoteData } from '../../store';
import { StemPlayer } from '../System/StemPlayer';

// We'll expose this globally so the Game can use it
export const stemPlayer = typeof window !== 'undefined' && (window as any)._stemPlayer 
  ? (window as any)._stemPlayer 
  : new StemPlayer();

if (typeof window !== 'undefined') {
  (window as any)._stemPlayer = stemPlayer;
}

export function Menu() {
  const { startGame, score, combo, maxCombo, difficulty, setDifficulty } = useStore();
  const [loading, setLoading] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [loadProgress, setLoadProgress] = useState<{
    loaded: number;
    total: number;
    currentFile: string;
    error?: string;
  } | null>(null);
 
  const onStart = async () => {
    if (loading || analyzing) return;
    
    // Resume or create context synchronously with user gesture
    if (!stemPlayer.ctx) {
      stemPlayer.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (stemPlayer.ctx && stemPlayer.ctx.state === 'suspended') {
      stemPlayer.ctx.resume();
    }
    
    // Play a tiny silent buffer immediately to permanently unlock iOS Safari audio context
    try {
      const g = stemPlayer.ctx.createGain();
      g.gain.value = 0;
      const osc = stemPlayer.ctx.createOscillator();
      osc.connect(g);
      g.connect(stemPlayer.ctx.destination);
      osc.start(0);
      osc.stop(0.001);
    } catch (e) {
      console.error(e);
    }
    
    setLoading(true);
    setLoadProgress({ loaded: 0, total: 7, currentFile: "Initializing AudioContext..." });
    try {
      if (!loaded) {
        await stemPlayer.load(setLoadProgress);
        setLoaded(true);
      }
      setLoading(false);
    } catch (e: any) {
      console.error("Audio Load Error in Menu:", e);
      setLoadProgress(prev => ({
        loaded: prev?.loaded || 0,
        total: 7,
        currentFile: '',
        error: e.message || String(e)
      }));
      setLoading(false);
      return; // Do NOT start the game if loading failed
    }
    
    setAnalyzing(true);
    
    // Defer analysis to allow UI to update
    setTimeout(() => {
      let analyzed: ReturnType<typeof stemPlayer.analyzeNotes> = [];
      try {
        analyzed = stemPlayer.analyzeNotes(difficulty);
      } catch (e) {
        console.error(e);
      }
      
      let notes: NoteData[] = [];
      
      if (analyzed.length > 0) {
        notes = analyzed.map((a, i) => ({
          id: `note-${i}`,
          time: a.time,
          lane: a.lane,
          hit: false,
          missed: false,
          hittable: true
        }));
      } else {
        const bpm = difficulty === 'hard' ? 180 : difficulty === 'medium' ? 120 : 80;
        const beatInterval = 60 / bpm;
        for (let t = 2; t < 195; t += beatInterval) {
          if (Math.random() > 0.3) {
            notes.push({
              id: `note-${t}`, time: t, lane: Math.floor(Math.random() * 5), hit: false, missed: false, hittable: true
            });
          }
        }
      }
      
      startGame(notes);
      stemPlayer.play();
      setAnalyzing(false);
    }, 50);
  };

  return (
    <div className="relative flex flex-col items-center justify-center w-full h-full overflow-hidden bg-black p-8 font-cyber selection:bg-pink-500">
      <div className="absolute inset-0 bg-[url(/splashscreen.png)] bg-cover bg-center brightness-50 opacity-40 mix-blend-screen z-0 pointer-events-none transition-opacity duration-1000"></div>
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-indigo-900/40 via-[#050011]/80 to-black z-0 pointer-events-none"></div>
      
      <div className="absolute inset-0 z-0 opacity-20 pointer-events-none" style={{ backgroundImage: 'linear-gradient(rgba(255, 255, 255, 0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(255, 255, 255, 0.05) 1px, transparent 1px)', backgroundSize: '50px 50px' }}></div>

      <div className="z-10 text-center relative">
        <h1 className="text-8xl md:text-9xl font-black mb-2 text-transparent bg-clip-text bg-gradient-to-br from-cyan-400 via-purple-500 to-pink-500 drop-shadow-[0_0_15px_rgba(236,72,153,0.5)] tracking-tighter hover:scale-105 transition-transform duration-700">
          GUITAR GOD
        </h1>
        <div className="text-pink-500 tracking-[0.5em] font-bold text-xl md:text-2xl mb-12 drop-shadow-[0_0_8px_rgba(236,72,153,0.8)]">CHORD BREAKER</div>
      </div>
      
      <div className="z-10 bg-black/60 backdrop-blur-xl border border-white/10 p-10 rounded-3xl mb-8 w-full max-w-2xl text-center shadow-[0_0_50px_rgba(0,0,0,0.8)] relative overflow-hidden group">
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 via-purple-500/10 to-pink-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>
        <h2 className="text-3xl font-bold text-white mb-2 tracking-wide font-sans relative z-10">NEFFEX - Fight Back</h2>
        <p className="text-zinc-400 mb-8 font-medium font-sans relative z-10">Master the track. Don't drop the combo.</p>
        
        <div className="flex justify-center gap-4 mb-8 relative z-10">
          <button 
            id="difficulty-easy-btn"
            onClick={() => setDifficulty('easy')}
            className={`px-6 py-2 rounded-full font-bold uppercase transition-all cursor-pointer ${difficulty === 'easy' ? 'bg-green-500 text-black shadow-[0_0_20px_rgba(34,197,94,0.6)]' : 'bg-transparent border border-green-500/50 text-green-400 hover:bg-green-500/20'}`}
          >
            Easy
          </button>
          <button 
            id="difficulty-medium-btn"
            onClick={() => setDifficulty('medium')}
            className={`px-6 py-2 rounded-full font-bold uppercase transition-all cursor-pointer ${difficulty === 'medium' ? 'bg-yellow-500 text-black shadow-[0_0_20px_rgba(234,179,8,0.6)]' : 'bg-transparent border border-yellow-500/50 text-yellow-400 hover:bg-yellow-500/20'}`}
          >
            Medium
          </button>
          <button 
            id="difficulty-hard-btn"
            onClick={() => setDifficulty('hard')}
            className={`px-6 py-2 rounded-full font-bold uppercase transition-all cursor-pointer ${difficulty === 'hard' ? 'bg-red-500 text-black shadow-[0_0_20px_rgba(239,68,68,0.6)]' : 'bg-transparent border border-red-500/50 text-red-400 hover:bg-red-500/20'}`}
          >
            Hard
          </button>
        </div>

        <div className="flex justify-center gap-4 mb-4 relative z-10">
          <div className="w-14 h-14 bg-gradient-to-b from-green-400 to-green-600 rounded-xl flex items-center justify-center font-bold text-black border-b-4 border-green-800 text-2xl shadow-[0_0_20px_rgba(34,197,94,0.4)]">A</div>
          <div className="w-14 h-14 bg-gradient-to-b from-red-400 to-red-600 rounded-xl flex items-center justify-center font-bold text-black border-b-4 border-red-800 text-2xl shadow-[0_0_20px_rgba(239,68,68,0.4)]">S</div>
          <div className="w-14 h-14 bg-gradient-to-b from-yellow-400 to-yellow-600 rounded-xl flex items-center justify-center font-bold text-black border-b-4 border-yellow-800 text-2xl shadow-[0_0_20px_rgba(234,179,8,0.4)]">D</div>
          <div className="w-14 h-14 bg-gradient-to-b from-blue-400 to-blue-600 rounded-xl flex items-center justify-center font-bold text-black border-b-4 border-blue-800 text-2xl shadow-[0_0_20px_rgba(59,130,246,0.4)]">F</div>
          <div className="w-14 h-14 bg-gradient-to-b from-orange-400 to-orange-600 rounded-xl flex items-center justify-center font-bold text-black border-b-4 border-orange-800 text-2xl shadow-[0_0_20px_rgba(249,115,22,0.4)]">G</div>
        </div>
      </div>

      {score > 0 && (
        <div className="z-10 mb-10 flex space-x-12 bg-black/40 backdrop-blur-md border border-white/5 px-10 py-4 rounded-full">
          <div className="text-center">
            <div className="text-zinc-500 text-sm tracking-widest uppercase mb-1">Last Score</div>
            <div className="text-3xl font-bold text-white">{score.toLocaleString()}</div>
          </div>
          <div className="text-center">
            <div className="text-zinc-500 text-sm tracking-widest uppercase mb-1">Max Combo</div>
            <div className="text-3xl font-bold text-pink-400">{maxCombo}</div>
          </div>
        </div>
      )}

      {loadProgress && (
        <div className="z-10 bg-black/80 border border-white/10 p-5 rounded-2xl w-full max-w-md text-center mb-8 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-cyan-400 to-pink-500"></div>
          <div className="text-zinc-400 text-xs uppercase tracking-widest font-bold mb-2 flex justify-between px-1">
            <span>Asset Downloader</span>
            <span className="font-mono text-cyan-400">{loadProgress.loaded}/{loadProgress.total}</span>
          </div>
          <div className="h-3 w-full bg-zinc-950 rounded-full overflow-hidden mb-3 border border-zinc-900 p-[2px]">
            <div 
              className={`h-full rounded-full transition-all duration-300 ${loadProgress.error ? 'bg-red-500 animate-pulse' : 'bg-gradient-to-r from-cyan-400 via-indigo-500 to-pink-500'}`}
              style={{ width: `${Math.min(100, Math.max(5, (loadProgress.loaded / loadProgress.total) * 100))}%` }}
            ></div>
          </div>
          {loadProgress.error ? (
            <div className="text-red-500 text-xs font-mono font-bold animate-pulse text-left bg-red-950/40 p-2 rounded border border-red-500/20 max-h-24 overflow-y-auto">
              [FATAL_ERROR]: {loadProgress.error}
            </div>
          ) : (
            <div className="text-cyan-400 text-xs font-mono tracking-tight truncate text-left opacity-90">
              ⚡ {loadProgress.currentFile || 'Ready...'}
            </div>
          )}
        </div>
      )}

        <button
          disabled={loading || analyzing}
          onClick={onStart}
          className={`z-10 px-12 py-5 rounded-full font-bold text-2xl uppercase tracking-[0.2em] transition-all shadow-[0_0_30px_rgba(236,72,153,0.3)] ${
            !(loading || analyzing) ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:scale-110 hover:shadow-[0_0_50px_rgba(236,72,153,0.6)] hover:from-purple-500 hover:to-pink-500' : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
          }`}
        >
          <span className="drop-shadow-md">
            {loading ? 'DOWNLOADING ASSETS...' : analyzing ? 'ANALYZING NOTES...' : 'START GIG'}
          </span>
        </button>
    </div>
  );
}
