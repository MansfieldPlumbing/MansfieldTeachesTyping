/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React, { useEffect, useState } from 'react';
import { useStore } from './store';
import { Game } from './components/Game/Game';
import { Menu } from './components/UI/Menu';

function App() {
  const gameState = useStore((s) => s.gameState);

  return (
    <div className="relative w-full h-screen bg-black overflow-hidden select-none font-sans text-white">
      {gameState === 'menu' && <Menu />}
      {gameState === 'playing' && <Game />}
      {gameState === 'gameover' && <Menu />}
    </div>
  );
}

export default App;
