import { create } from 'zustand';

export interface NoteData {
  id: string;
  time: number; // time in seconds
  lane: number; // 0 to 3
  hit: boolean;
  missed: boolean;
  hittable: boolean; // within hit window
}

export interface HitFeedback {
  id: string;
  text: string;
  color: string;
  lane: number;
}

interface GameState {
  score: number;
  combo: number;
  maxCombo: number;
  multiplier: number;
  notes: NoteData[];
  isPlaying: boolean;
  gameState: 'menu' | 'loading' | 'playing' | 'gameover';
  difficulty: 'easy' | 'medium' | 'hard';
  currentBPM: number;
  recentHits: HitFeedback[];
  
  startGame: (notes: NoteData[]) => void;
  hitNote: (lane: number, currentTime: number) => { hit: boolean; noteId?: string };
  missNote: (id: string, lane?: number) => void;
  reset: () => void;
  setGameState: (s: 'menu' | 'loading' | 'playing' | 'gameover') => void;
  setDifficulty: (diff: 'easy' | 'medium' | 'hard') => void;
  removeHitFeedback: (id: string) => void;
}

const HIT_WINDOW = 0.2; // +/- 0.2s

export const useStore = create<GameState>((set, get) => ({
  score: 0,
  combo: 0,
  maxCombo: 0,
  multiplier: 1,
  notes: [],
  isPlaying: false,
  gameState: 'menu',
  difficulty: 'medium',
  currentBPM: 100, // guess
  recentHits: [],

  setGameState: (state) => set({ gameState: state }),
  setDifficulty: (difficulty) => set({ difficulty }),

  startGame: (notes) => set({
    gameState: 'playing',
    notes,
    score: 0,
    combo: 0,
    maxCombo: 0,
    multiplier: 1,
    isPlaying: true,
    recentHits: []
  }),

  removeHitFeedback: (id) => set(state => ({
    recentHits: state.recentHits.filter(h => h.id !== id)
  })),

  hitNote: (lane, currentTime) => {
    let hitNote: NoteData | null = null;
    let minDiff = Infinity;

    const { notes, combo } = get();

    // Find closest note in lane
    for (const note of notes) {
      if (note.lane === lane && !note.hit && !note.missed) {
        const diff = Math.abs(note.time - currentTime);
        if (diff <= HIT_WINDOW && diff < minDiff) {
          hitNote = note;
          minDiff = diff;
        }
      }
    }

    if (hitNote) {
      // successful hit
      const newCombo = combo + 1;
      const mult = Math.min(4, Math.floor(newCombo / 10) + 1);
      
      let pts = 50;
      let text = "GOOD";
      let color = "text-blue-400 font-bold drop-shadow-[0_0_8px_rgba(59,130,246,0.8)]";
      if (minDiff < 0.05) {
        pts = 100;
        text = "PERFECT";
        color = "text-yellow-400 font-bold drop-shadow-[0_0_8px_rgba(250,204,21,0.8)]";
      } else if (minDiff > 0.12) {
        pts = 20;
        text = "OK";
        color = "text-green-400 font-bold drop-shadow-[0_0_8px_rgba(74,222,128,0.8)]";
      }
      
      const hitId = Math.random().toString();
      
      set((state) => ({
        score: state.score + pts * mult,
        combo: newCombo,
        maxCombo: Math.max(state.maxCombo, newCombo),
        multiplier: mult,
        notes: state.notes.map(n => n.id === hitNote!.id ? { ...n, hit: true } : n),
        recentHits: [...state.recentHits, { id: hitId, text, color, lane }]
      }));
      
      setTimeout(() => {
        get().removeHitFeedback(hitId);
      }, 800);
      
      return { hit: true, noteId: hitNote.id };
    } else {
      // pressed but no note there, or too far
      set((state) => ({ combo: 0, multiplier: 1 }));
      return { hit: false };
    }
  },

  missNote: (id, lane) => {
    const hitId = Math.random().toString();
    set((state) => ({
      combo: 0,
      multiplier: 1,
      notes: state.notes.map(n => n.id === id ? { ...n, missed: true } : n),
      recentHits: lane !== undefined ? [...state.recentHits, { id: hitId, text: "MISS", color: "text-red-500 font-bold drop-shadow-[0_0_8px_rgba(239,68,68,0.8)]", lane }] : state.recentHits
    }));
    
    if (lane !== undefined) {
      setTimeout(() => {
        get().removeHitFeedback(hitId);
      }, 500);
    }
  },

  reset: () => set({
    gameState: 'menu',
    score: 0,
    combo: 0,
    multiplier: 1,
    notes: [],
    isPlaying: false,
    recentHits: []
  })
}));
